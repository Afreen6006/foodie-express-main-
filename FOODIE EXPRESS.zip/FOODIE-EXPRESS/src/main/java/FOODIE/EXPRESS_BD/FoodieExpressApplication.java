package FOODIE.EXPRESS_BD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodieExpressApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodieExpressApplication.class, args);
	}

}
